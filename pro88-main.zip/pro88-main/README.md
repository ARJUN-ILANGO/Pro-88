# book-santa-stage-11
solution for 87
